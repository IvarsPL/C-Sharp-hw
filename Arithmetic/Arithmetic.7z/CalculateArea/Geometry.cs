﻿using System;

namespace CalculateArea
{
    public class Geometry
    {
        public static double areaOfCircle(decimal radius)
        {
            throw new NotImplementedException();
        }

        public static double areaOfRectangle(decimal length, decimal width)
        {
            throw new NotImplementedException();
        }

        public static double areaOfTriangle(decimal ground, decimal h)
        {
            throw new NotImplementedException();
        }
    }
}
