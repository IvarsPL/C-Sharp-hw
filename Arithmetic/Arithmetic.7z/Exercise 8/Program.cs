﻿using System;

namespace Exercise_8
{
    class Program
    {

        static double EmployeePay(double pay, int hours)
        {
            var baseHour = 60;
            var basePay = 8.00;
            var normalHours = 40;
            double salary = 0;

            if (pay < basePay) throw new Exception("Please double check the base pay."); //Console.WriteLine(""Please double check the base pay."");
            if (hours > baseHour) throw new Exception("You can't work that much."); //Console.WriteLine("You can't work that much.");
            if (hours > normalHours)
            {
                int extraHours = hours - normalHours;
                double extraPay = (pay * 1.5) * extraHours;
                salary = extraPay + (pay * normalHours);
            }
            else if (hours < normalHours) salary = hours * pay;

            return salary;
        }
        static void Main()
        {
           
                Console.WriteLine(EmployeePay(7.50, 35));
                Console.WriteLine(EmployeePay(8.20, 47));
                Console.WriteLine(EmployeePay(10.00, 73));



                Console.ReadKey();

        }


    }
}
